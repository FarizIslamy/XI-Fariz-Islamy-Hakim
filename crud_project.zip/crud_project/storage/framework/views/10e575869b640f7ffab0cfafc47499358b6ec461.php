<!DOCTYPE html>
<html>
<head>
    <title>Tambah Kontak</title>
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
</head>
<body>
    <div class="container">
        <h1>Tambah Kontak</h1>
        <form action="<?php echo e(route('contacts.store')); ?>" method="POST">
            <?php echo csrf_field(); ?>
            <div class="form-group">
                <label>Nama</label>
                <input type="text" name="name" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Email</label>
                <input type="email" name="email" class="form-control" required>
            </div>
            <div class="form-group">
                <label>Telepon</label>
                <input type="text" name="phone" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Simpan</button>
            <a href="<?php echo e(route('contacts.index')); ?>" class="btn btn-secondary">Kembali</a>
        </form>
    </div>
</body>
</html>
<?php /**PATH C:\xampp\htdocs\crud_project\resources\views/contacts/create.blade.php ENDPATH**/ ?>